/**
 * 
 */
package com.d14.interfaces;


/**
 * @author Adnan
 *
 */
public interface Writer {
	
	public void write(String text);

}
